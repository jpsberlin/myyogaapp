package jpsberlin.myyogaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MeditationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meditation)

        val buttonSaTaNaMa = findViewById<Button>(R.id.buttonSaTaNaMa)
        val textMeditation = findViewById<TextView>(R.id.textMeditation)


        buttonSaTaNaMa.setOnClickListener {


            textMeditation.setText(R.string.meditationSatanama)


            // connected buttonSaTaNaMa with setOnListner with textAsana
        }

        val buttonHeart = findViewById<Button>(R.id.buttonHeart)
        buttonHeart.setOnClickListener {

            //val textAsana = findViewById<TextView>(R.id.textAsana)
            //textAsana.text = "catcow is to make you fit like a dog"
            textMeditation.setText(R.string.meditationHeart)

            // connected butteonSunsalute with setOnListner with textAsana
        }

    }

    fun goHome(view: View){
        finish()
        // this is goHome Button
    }

}
