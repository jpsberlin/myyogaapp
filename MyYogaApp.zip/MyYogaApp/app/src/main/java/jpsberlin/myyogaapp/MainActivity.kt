package jpsberlin.myyogaapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun openAsana(view: View) {

        // Create an Intent to start the second activity
        val asanaIntent = Intent(this, AsanaActivity::class.java)

// Start the new activity.
        startActivity(asanaIntent)
    }

    fun openMeditation(view: View) {

        // Create an Intent to start the second activity
        val meditationIntent = Intent(this, MeditationActivity::class.java)

// Start the new activity.
        startActivity(meditationIntent)
    }

    fun openPranayama(view: View) {

        // Create an Intent to start the second activity
        val pranayamaIntent = Intent(this, PranayamaActivity::class.java)

// Start the new activity.
        startActivity(pranayamaIntent)
    }

}
