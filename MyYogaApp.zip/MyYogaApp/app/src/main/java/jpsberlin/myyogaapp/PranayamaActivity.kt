package jpsberlin.myyogaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class PranayamaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pranayama)

        val buttonFireBreath = findViewById<Button>(R.id.buttonFireBreath)
        val textPranayama = findViewById<TextView>(R.id.textPranayama)


        buttonFireBreath.setOnClickListener {


            textPranayama.setText(R.string.breathFire)


            // connected butteonFireBreath with setOnListner with textPranayama
        }

        val buttonSitaliBreath = findViewById<Button>(R.id.buttonSitaliBreath)
        buttonSitaliBreath.setOnClickListener {

            textPranayama.setText(R.string.breathSitali)

            // connected butteonSitali with setOnListner with textPranayam
        }

    }

    fun goHome(view: View){
        finish()
        // this is goHome Button
    }

}
