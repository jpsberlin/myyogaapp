package jpsberlin.myyogaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class AsanaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asana)

        val buttonSunsalute = findViewById<Button>(R.id.buttonSunsalute)
        val textAsana = findViewById<TextView>(R.id.textAsana)


        buttonSunsalute.setOnClickListener {


            textAsana.setText(R.string.asanaSunsalute)


            // connected butteonSunsalute with setOnListner with textAsana
        }

        val buttonCatCow = findViewById<Button>(R.id.buttonCatCow)
        buttonCatCow.setOnClickListener {

            //val textAsana = findViewById<TextView>(R.id.textAsana)
            //textAsana.text = "catcow is to make you fit like a dog"
            textAsana.setText(R.string.asanaCatCow)

            // connected butteonSunsalute with setOnListner with textAsana
        }
    }

    fun goHome(view: View) {
        finish()
        // this is goHome Button
    }

    fun showSunsalute() {

    }
}
